<?php

if(isset($_POST["submit"])){

$filteredtype = $_POST['radioBtn']; 


if($filteredtype == "switch"){
    header("location: catalogue.php?type=switch");
    exit();
}
if($filteredtype == "router"){
    header("location: catalogue.php?type=router");
    exit();
}
if($filteredtype == "all"){
    header("location: catalogue.php?type=all");
    exit();
}

if($filteredtype == "asus"){
    header("location: catalogue.php?type=asus");
    exit();
}
if($filteredtype == "huawei"){
    header("location: catalogue.php?type=huawei");
    exit();
}
if($filteredtype == "cisco"){
    header("location: catalogue.php?type=cisco");
    exit();
}
if($filteredtype == "tp-link"){
    header("location: catalogue.php?type=tp-link");
    exit();
}
if($filteredtype == "ZyXEL"){
    header("location: catalogue.php?type=ZyXEL");
    exit();
}
if($filteredtype == "dell"){
    header("location: catalogue.php?type=dell");
    exit();
}
if($filteredtype == "xiomi"){
    header("location: catalogue.php?type=xiomi");
    exit();
}
}else{
    header("location: catalogue.php?type=all");
    exit();
}
