<?php

function wrongEmail($email){ 
    $result;
    if(!filter_var($email, FILTER_VALIDATE_EMAIL)){                                                                                                             // проверява дали  емаил е написан валидно 
        $result = true;
    }else{
        $result = false;
    }
    return $result;
}

function existingEmail($con, $email){
      $sql = "SELECT * FROM `registration` WHERE `email` = ?;";                                                                                                                 // изкарва вс от регистратио и проверява дали има втори такъв емаил
      $stmt = mysqli_stmt_init($con);                                                                                                                                                    // активира се връзката 
      if(!mysqli_stmt_prepare($stmt, $sql)){                                                                                                                                                            // преперва се вар стмт с куерито 
        header("location: register.php?error=stmtfailed");
        exit();
      }

      mysqli_stmt_bind_param($stmt, "s", $email);                                                                                                                                                       // баиндва стмт със стринг който се взима от променливата емаил от цигнина 
      mysqli_stmt_execute($stmt);                                                                                                                                                                               // екзекютва вече 

      $resultData = mysqli_stmt_get_result($stmt);                                                                                                                                                                      // в тая променлива се запазва резултата (вс което е селектнато)

      if($row = mysqli_fetch_assoc($resultData)){                                                                                                                                                               // ретърнва всички роллове 
          return $row;

      }else{
          $result = false;
          return $result;
      }

      mysqli_stmt_close($stmt);                                                                                                                                                                                             // затваря се стмт 
}


function createNewUser($con, $name, $email, $phone, $password){                                                                                                                                                                                                 // взима параметрите за да 
    $sql = "INSERT INTO `registration` (`userName`, `email`, `number`, `password`) VALUES (?, ?, ?, ?);";
    $stmt = mysqli_stmt_init($con);
    if(!mysqli_stmt_prepare($stmt, $sql)){
      header("location: registration.php?error=statementfailed");
      exit();
    }

    mysqli_stmt_bind_param($stmt, "ssss", $name, $email, $phone, $password);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    
    header("location: login.php");
      exit();
}

function login($con, $email, $password){
    $emailExists = existingEmail($con, $email);

if($emailExists === false){

    header("location: login.php?error=wrongemail");
      exit();
}
$s = " SELECT * FROM `registration` WHERE `email` = '$email' && `password` = '$password';";                                                                             // ново куери от което се взима тия данни 
$result = mysqli_query($con, $s);                                                                                                                   // ехе куерито 
$num = mysqli_num_rows($result);                                                                                                                    // взима роловете 

if($num === 0){
    header("location: login.php?error=profiledoesntexist");
    exit();
}else if($num === 1){                                                                                                                                                       // почва сесията 
    session_start();
    $_SESSION["userid"]=$emailExists["id"];
    $_SESSION["useremail"]=$emailExists["email"];

    header("location: mainPage.php?d=g");
    exit();
}
}