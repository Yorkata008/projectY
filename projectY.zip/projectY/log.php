<?php

if(isset($_POST["submit"])){

    $email = $_POST['email'];
    $password = $_POST['password'];

    $con = mysqli_connect('localhost', 'root', '','projecty'); 
    require_once 'functions.php';


login($con, $email, $password);


}else{
    header("location: login.php");
    exit();
}



