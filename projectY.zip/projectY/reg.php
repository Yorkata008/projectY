<?php

if(isset($_POST["submit"])){                                                                                                                                                                                                // ако е натиснат бутона субмит(част оф формуляр) се случва ....

	$name = $_POST['user'];
	$email = $_POST['email'];
	$phone = $_POST['number'];                                                                                                                      // задава им се стойност въведена от потребителя  и се използват в create new user функция 
	$password = $_POST['password']; 

	$con = mysqli_connect('localhost', 'root', '','projecty'); 
    require_once 'functions.php';                                                                                                               // извиква файла веднъж за да го използва 


if(wrongEmail($email) !== false){                                                                                                                       // проверява дали е email е правилно написан. Предварителна функция в php 
    header("location: registration.php?error=invalidemail");
    exit();
}

if(existingEmail($con, $email) !== false){
    header("location: registration.php?error=existingemail");
    exit();
}

createNewUser($con, $name, $email, $phone, $password);                                                                                          // функ приема променливите като аргументи 

}else{
    header("location: registration.php?error=doesntworkthatwaypal");
    exit();
}
// el рepe