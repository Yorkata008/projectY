<?php

session_start();

include 'connectionProductDataBase.php';   
    include 'functions.php';
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100&display=swap" rel="stylesheet">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
        <link rel="stylesheet" href="mainStyle.css"/>
        <link rel="stylesheet" href="background.css"/>
     
        <title>YORKATA</title> 

    </head>
    <header>
        <nav>
        <a href="mainPage.php"><img src="photo/YNetLOGO.png" class="logo"></img> </a>

            
            <ul class="nav-links">

                <?php
                    
if(isset($_SESSION["useremail"])){
        echo "<li><a class='activate' href='profile.php'>Profile</a></li>";
        echo "<li><a href='catalogue.php?type=all'>Catalogue</a></li>";
        echo "<li><a href='services.php'>Services</a></li>";
        echo "<li><a href='contacts.php'>Contact</a></li>";
        echo "<li><a href='addtocart.php?msg=none'><i class='fa fa-shopping-bag' style='color:#b8b8b8'></i></a></li>";
        echo "<li><a href='logout.php'>Logout</a></li>";


    }else {
        echo "<li><a class='activate' href='login.php'>Login</a></li>";
        echo "<li><a href='catalogue.php?type=all'>Catalogue</a></li>";
        echo "<li><a href='services.php'>Services</a></li>";
        echo "<li><a href='contacts.php'>Contact</a></li>";
    }

?>
            </ul>
            <div class="burger">
                <div class="line1"></div>
                <div class="line2"></div>
                <div class="line3"></div>
            </div>
        </nav>
        <script src="mp.js"></script>
    </header>
<body>


    <?php
    
    
if(isset($_SESSION["useremail"])){ 
        if(isset($_POST["cartADD"])){ 
            
                $userid= $_SESSION["userid"];
                $ime= $_POST['ime'];
                $sigurnost= $_POST['sigurnost'];
                $skorost= $_POST['skorost'];
                $snimka= $_POST['snimka'];
                $cena= $_POST['cena'];
                $EAN= $_POST['EAN'];
                $kapacitet= $_POST['kapacitet'];
                $mac_adres= $_POST['mac_adres'];
                $pamet= $_POST['pamet'];
                $portove= $_POST['portove'];
                $zahranvane= $_POST['zahranvane'];
                
                 
$sqlUNO = "INSERT INTO `cart` (id ,ime, sigurnost, skorost, snimka, cena, EAN, kapacitet, mac_adres, pamet, portove, zahranvane)
 VALUES ('$userid', '$ime', '$sigurnost', '$skorost', '$snimka', '$cena', '$EAN', '$kapacitet', '$mac_adres', '$pamet', '$portove', '$zahranvane');";
$squeryUNO = mysqli_query($conP, $sqlUNO);
    
    }}else{
        header("location: catalogue.php?type=notlogged");
                exit();
    }
?>
<?php
        $userID= $_SESSION["userid"];  
        $query = "SELECT * FROM `cart` WHERE `id`=$userID;";  
        $result = mysqli_query($conP, $query);
        $resultCheck = mysqli_num_rows($result);
        $sum=0;
        if($resultCheck > 0){
            while ($rows = mysqli_fetch_assoc($result)){  
                $sum += $rows['cena']; 
                echo "<div class='card-container'>";
                echo "<form action='addtocart.php' method = 'post'>";
                echo "<div class='card'>";
                echo "<div class='card-inner'>";
                echo "<div class='front-face'>";
                echo "<img src='" . $rows['snimka'] . "'>";
                echo "<select name='snimka' class='asen'><option value='" . $rows['snimka'] . "'></option></select>";
                echo "</div>";
                echo "<div class='back-face'>";
                echo "<h2>" . $rows['ime'] . "</h2>";
                echo "<select name='ime' class='asen'><option value='" . $rows['ime'] . "'></option></select>";
                echo "<p>" . $rows['cena'] ." лв.</p>";
                echo "<select name='cena' class='asen'><option value='" . $rows['cena'] . "'></option></select>";
                echo "<select name='cartproductID' class='asen'><option value='" . $rows['primID'] . "'></option></select>";
                echo "<input type ='submit' name = 'cartDEL' class='itembtn' value = 'delete'>";
                echo "</div>";
                echo "</div>";
                echo "</div>";
                echo "</form>";
                echo "</div>";
}}


echo "<div class='buyFromCart'>";
echo "<form action='addtocart.php' method='post'>";
echo "<h3 class = 'purchase'>Цена на всичко: " . $sum . " лв.</h3>";
echo "<div class='buyFCButn'>";
echo "<input type='submit' name='buyFC' value='PURCHASE'>";
echo "</div>";
echo "</form>";
echo "</div>";

if(isset($_POST["buyFC"])){

    
    $kupuvach = $_SESSION["userid"]; 
    $sqls = "INSERT INTO  `orders` (ime,cena) VALUES ('imence','cenichka')";
    if(mysqli_query($conP, $sqls)){
        $last_id = mysqli_insert_id($conP); 
    }
    $SQLi = "INSERT INTO  `orders` (idNaPoruchka, ime, cena, userId, snimka) 
    SELECT $last_id, ime, cena, id, snimka FROM `cart` WHERE  `id` = $kupuvach;";

    $othrSTMT = mysqli_query($conP, $SQLi);
    
    $squery = "DELETE FROM `cart` WHERE `id` = $userID;";
    $query = mysqli_query($conP, $squery);

    header("location: thxmgs.php");
    exit();

}


if(isset($_POST["cartDEL"])){
    $cpID = $_POST['cartproductID'];
    $sqli = "DELETE FROM `cart` WHERE `primID` ='$cpID';";

    mysqli_query($conP, $sqli);

    header("location: addtocart.php");
exit();
}
?>

</body>
</html>