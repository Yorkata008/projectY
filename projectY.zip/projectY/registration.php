<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="mainStyle.css">
        <link rel="stylesheet" href="background.css"/>
        <title>YORKATA</title> 

    </head>
    <header>
        <nav>
        <a href="mainPage.php"><img src="photo/YNetLOGO.png" class="logo"></img> </a>
        </nav>
    </header>
    <body>
        
        <div class="container">
            <div class="title">Регистрация</div>
            <form action="reg.php" method="post">
                <div class="user-details">
                    <div class="input-box">
                        <span class="details"></span>
                        <input type="text" name="user" placeholder="Име" required>
                    </div>
                    <div class="input-box">
                        <span class="details"></span>
                        <input type="text" name="email" placeholder="Email" required>
                    </div>
                    <div class="input-box">
                        <span class="details"></span>
                        <input type="text" name="number" placeholder="Телефонен номер" required minlength="10" maxlength="10">
                    </div>
                    <div class="input-box">
                        <span class="details"></span>
                        <input type="password" name="password" placeholder="Парола" required minlength="3">
                    </div>
                </div>
                <div class="button">
                    <input type="submit" name="submit" value="Регистрация">
                </div>
            </form>
        </div>
    </body>




</html>