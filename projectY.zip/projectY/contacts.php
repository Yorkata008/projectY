<?php

session_start();
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="mainStyle.css"/>
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
        <title>YORKATA</title> 
        <link rel="stylesheet" href="https://unpkg.com/swiper@8/swiper-bundle.min.css"/>
        <link rel="stylesheet" href="background.css"/>
    </head>
    
    <header>
        <nav>
        <a href="mainPage.php"><img src="photo/YNetLOGO.png" class="logo"></img> </a>

            
            <ul class="nav-links">
                <!--  -->
                <?php
            
if(isset($_SESSION["useremail"])){
        echo "<li><a class='activate' href='profile.php'>Profile</a></li>";
        echo "<li><a href='catalogue.php?type=all'>Catalogue</a></li>";
        echo "<li><a href='services.php'>Services</a></li>";
        echo "<li><a href='contacts.php'>Contact</a></li>";
        echo "<li><a href='addtocart.php?msg=none'><i class='fa fa-shopping-bag' style='color:#b8b8b8'></i></a></li>";
        echo "<li><a href='logout.php'>Logout</a></li>";


    }else {
        echo "<li><a class='activate' href='login.php'>Login</a></li>";
        echo "<li><a href='catalogue.php?type=all'>Catalogue</a></li>";
        echo "<li><a href='services.php'>Services</a></li>";
        echo "<li><a href='contacts.php'>Contact</a></li>";
    }

?>
            </ul>
            <div class="burger">
                <div class="line1"></div>
                <div class="line2"></div>
                <div class="line3"></div>
            </div>
        </nav>
        <script src="mp.js"></script>
    </header>
    <body>
        
    <div class="contact-info">
        <h1>CONTACTS</h1>
    </div>
    <div class="contact-info">
    <p>Email: danninikolov08@mail.com<br> Phone: 0877662558</p>
    <p class="gmaps">
    
    <iframe  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2934.5773956804337!2d23.34281191544348!3d42.649118279168526!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x40aa84229de7af4d%3A0x869656585276ac62!2z0JrQu9GD0LEgMzM!5e0!3m2!1sbg!2sbg!4v1647422079776!5m2!1sbg!2sbg" width="600" height="450"  allowfullscreen="" loading="lazy"></iframe>
    </p>

    </div>

</body>