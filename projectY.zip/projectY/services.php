<?php

session_start();
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="mainStyle.css"/>
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
        <title>YORKATA</title> 
        <link rel="stylesheet" href="https://unpkg.com/swiper@8/swiper-bundle.min.css"/>
        <link rel="stylesheet" href="background.css"/>
    
    </head>
    <header>
        <nav>
        <a href="mainPage.php"><img src="photo/YNetLOGO.png" class="logo"></img> </a>

            
            <ul class="nav-links">
                
                <?php
            
if(isset($_SESSION["useremail"])){
    echo "<li><a class='activate' href='profile.php'>Profile</a></li>";
        echo "<li><a href='catalogue.php?type=all'>Catalogue</a></li>";
        echo "<li><a href='services.php'>Services</a></li>";
        echo "<li><a href='contacts.php'>Contact</a></li>";
        echo "<li><a href='addtocart.php?msg=none'><i class='fa fa-shopping-bag' style='color:#b8b8b8'></i></a></li>";
        echo "<li><a href='logout.php'>Logout</a></li>";


    }else {
        echo "<li><a class='activate' href='login.php'>Login</a></li>";
        echo "<li><a href='catalogue.php?type=all'>Catalogue</a></li>";
        echo "<li><a href='services.php'>Services</a></li>";
        echo "<li><a href='contacts.php'>Contact</a></li>";
    }

?>
            </ul>
            <div class="burger">
                <div class="line1"></div>
                <div class="line2"></div>
                <div class="line3"></div>
            </div>
        </nav>
        <script src="mp.js"></script>
    </header>
    <body>

    <?php
        require_once 'connectionProductDataBase.php';
        $q = "SELECT * FROM `service`;";
        $r = mysqli_query($conP, $q);
        $rCheck = mysqli_num_rows($r);

        if($rCheck > 0){
            while ($rows = mysqli_fetch_assoc($r)){
             
echo   "<div class='service-container'>";
echo "<form action='addtocart.php' method = 'post'>";
echo   "<div class='services'>";
echo   "<p class = 'plan'>Plan</p>";                     
echo   "<h3>" . $rows['ime'] . "</h3>";
echo "<select name='ime' class='asen'><option value='" . $rows['ime'] . "'></option></select>";
echo   "</div>";
echo   "<div class='services'>";  
echo   "<p>" . $rows['harakteristika'] ."</p>"; 
echo "<select name='harakteristika' class='asen'><option value='" . $rows['harakteristika'] . "'></option></select>";  
echo   "</div>"; 
echo   "<div class='services'>";    
echo   "<p class= 'money'>" . $rows['cena'] ." лв.</p>";
echo "<select name='cena' class='asen'><option value='" . $rows['cena'] . "'></option></select>"; 
echo   "</div>";
echo "<select name='kapacitet' class='asen'><option value='NULL'></option></select>";
echo "<select name='snimka' class='asen'><option value='photo/service.png'></option></select>";
echo "<select name='mac_adres' class='asen'><option value='NULL'></option></select>";
echo "<select name='pamet' class='asen'><option value='NULL'></option></select>";
echo "<select name='portove' class='asen'><option value='NULL'></option></select>";
echo "<select name='zahranvane' class='asen'><option value='NULL'></option></select>";
echo "<select name='sigurnost' class='asen'><option value='NULL'></option></select>";
echo "<select name='skorost' class='asen'><option value='NULL'></option></select>";
echo "<select name='EAN' class='asen'><option value='NULL'></option></select>";
echo   "<div class='services-button'>";             
echo   "<input type='submit' name='cartADD' value='BUY'>";
echo   "</div>";
echo "<form>";
echo   "</div>"; 

           


}}
        ?>
    </body>
</html>