<?php

session_start();

?>
<!DOCTYPE html>
<html lang="en">
<head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="mainStyle.css"/>
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
        <title>YORKATA</title> 
        <link rel="stylesheet" href="https://unpkg.com/swiper@8/swiper-bundle.min.css"/>
        <link rel="stylesheet" href="background.css"/>
    
    </head>
    <header>
        <nav>
        <a href="mainPage.php"><img src="photo/YNetLOGO.png" class="logo"></img> </a>

            
            <ul class="nav-links">
                <?php
            
if(isset($_SESSION["useremail"])){
    echo "<li><a class='activate' href='profile.php'>Profile</a></li>";
        echo "<li><a href='catalogue.php?type=all'>Catalogue</a></li>";
        echo "<li><a href='services.php'>Services</a></li>";
        echo "<li><a href='contacts.php'>Contact</a></li>";
        echo "<li><a href='addtocart.php'><i class='fa fa-shopping-bag' style='color:#b8b8b8'></i></a></li>";
        echo "<li><a href='logout.php'>Logout</a></li>";


    }else {
        echo "<li><a class='activate' href='login.php'>Login</a></li>";
        echo "<li><a href='catalogue.php?type=all'>Catalogue</a></li>";
        echo "<li><a href='services.php'>Services</a></li>";
        echo "<li><a href='contacts.php'>Contact</a></li>";
    }

?>

            </ul>
            <div class="burger">
                <div class="line1"></div>
                <div class="line2"></div>
                <div class="line3"></div>
            </div>
        </nav>
        <script src="mp.js"></script>
    </header>
    <body>
    <?php
include_once 'connectionProductDataBase.php';

$kupuvachh = $_SESSION["userid"];
$query = "SELECT * FROM `orders` WHERE `userId`=$kupuvachh;";
    $result = mysqli_query($conP, $query);
    $resultCheck = mysqli_num_rows($result);
    echo "<div class='tbc'>";
    echo "<table class='content-table'>";
    echo"<thead>";
            echo "<tr>";
                echo "<td>ПРОДУКТИ: </td>";
                echo "<td>ЦЕНА: </td>";
                echo "<td>НОМЕР НА ПОРЪЧКА: </td>";
                echo "</tr>";
                echo"</thead>";
                echo"<tbody>";
    if($resultCheck > 0){
        while ($row = mysqli_fetch_assoc($result)){
            
                echo "<tr>";
                echo "<td>". $row['ime'] ."</td>";
                echo "<td>". $row['cena'] ."</td>";
                echo "<td>". $row['idNaPoruchka'] ."</td>";

                echo "</tr>";

                
        }}
        echo"</tbody>";
        echo "</table>";
        echo "</div>";

        $qu = "SELECT * FROM `registration` WHERE `id`=$kupuvachh;";
    $res = mysqli_query($conP, $qu);
    $resCheck = mysqli_num_rows($res);
    echo "<div class='tbc'>";
    echo "<table class='content-table'>";
    echo"<thead>";
            echo "<tr>";
                echo "<td>Име: </td>";
                echo "<td>Имейл: </td>";
                echo "<td>Номер: </td>";
                echo "</tr>";
                echo"</thead>";
                echo"<tbody>";
    if($resCheck > 0){
        while ($roww = mysqli_fetch_assoc($res)){
            
                echo "<tr>";
                echo "<td>". $roww['userName'] ."</td>";
                echo "<td>". $roww['email'] ."</td>";
                echo "<td>". $roww['number'] ."</td>";

                echo "</tr>";       
        }}
        echo"</tbody>";
        echo "</table>";
        echo"<div class='nameUpdate'>";
        echo"<form action='profile.php' method = 'post'>";
        echo"<input type='text' name='novoime' placeholder='Промяна на име'>";
        echo"<input type='submit' class ='updbtn' name='submit' value='Смени'>";
        echo "</form>";
        echo "</div>";
        echo "</div>";
?>
<?php
if(isset($_POST["submit"])){
    $newName = $_POST['novoime'];
    $useridd = $_SESSION["userid"];
    $sql = "UPDATE `registration` SET `userName` ='$newName' WHERE `id` = $useridd;";
    $squery = mysqli_query($conP, $sql);

    header("location: profile.php");
exit();
}
?>
</body>