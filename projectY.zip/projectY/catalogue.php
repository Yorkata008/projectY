<?php

session_start();
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100&display=swap" rel="stylesheet">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
        <link rel="stylesheet" href="mainStyle.css"/>
        <link rel="stylesheet" href="background.css"/>
 
     
        <title>YORKATA</title> 

    </head>
    <header>
        <nav>
        <a href="mainPage.php"><img src="photo/YNetLOGO.png" class="logo"></img> </a>

            
            <ul class="nav-links">

                <?php
            
if(isset($_SESSION["useremail"])){
        echo "<li><a class='activate' href='profile.php'>Profile</a></li>";
        echo "<li><a href='catalogue.php?type=all'>Catalogue</a></li>";
        echo "<li><a href='services.php'>Services</a></li>";
        echo "<li><a href='contacts.php'>Contact</a></li>";
        echo "<li><a href='addtocart.php?msg=none'><i class='fa fa-shopping-bag' style='color:#b8b8b8'></i></a></li>";
        echo "<li><a href='logout.php'>Logout</a></li>";


    }else {
        echo "<li><a class='activate' href='login.php'>Login</a></li>";
        echo "<li><a href='catalogue.php?type=all'>Catalogue</a></li>";
        echo "<li><a href='services.php'>Services</a></li>";
        echo "<li><a href='contacts.php'>Contact</a></li>";
    }

?>
            </ul>
            <div class="burger">
                <div class="line1"></div>
                <div class="line2"></div>
                <div class="line3"></div>
            </div>
        </nav>
        <script src="mp.js"></script>
    </header>
<body>

  
      
        <?php
        if(isset($_GET["type"])){   // ако е сетнат type го взима... гет го взима и иссет проверява 
            if($_GET["type"] == "router"){ // чеква 
                require_once 'connectionProductDataBase.php';
        $q = "SELECT * FROM `router`;";
        $r = mysqli_query($conP, $q);
        $rCheck = mysqli_num_rows($r);
        echo "<div class='filter'>";
        echo "<form action='filter.php' method='post'>";
        echo "<input type='radio' class='rdbtn' name='radioBtn' value='all' required>Всички";
        echo "<input type='radio' class='rdbtn' name='radioBtn' value='router' required>Рутери";
        echo "<input type='radio' class='rdbtn' name='radioBtn' value='switch' required>Суитчове";
        echo "<input type='radio' class='rdbtn' name='radioBtn' value='asus' required>Asus";
        echo "<input type='radio' class='rdbtn' name='radioBtn' value='huawei' required>Huawei";
        echo "<input type='radio' class='rdbtn' name='radioBtn' value='tp-link' required>tp-link";
        echo "<input type='radio' class='rdbtn' name='radioBtn' value='xiomi' required>xiomi";
        echo "<input type='radio' class='rdbtn' name='radioBtn' value='ZyXEL' required>ZyXL";
        echo "<input type='radio' class='rdbtn' name='radioBtn' value='dell' required>dell";
        echo "<input type='radio' class='rdbtn' name='radioBtn' value='cisco' required>cisco";
        echo "<div class='filter-button'>";
        echo "<input type='submit' name='submit' value='Филтрирай'>";
        echo "</div>";
        echo "</form>";
        echo "</div>";



        if($rCheck > 0){
            while ($rows = mysqli_fetch_assoc($r)){
             
echo "<div class='card-container'>";
echo "<form action='addtocart.php' method = 'post'>";
           echo "<div class='card'>";
               echo "<div class='card-inner'>";
                   echo "<div class='front-face'>";
                        echo "<img src='" . $rows['snimka'] . "'>";
                        echo "<select name='snimka' class='asen'><option value='" . $rows['snimka'] . "'></option></select>";
                   echo "</div>";
                   echo "<select name='kapacitet' class='asen'><option value='NULL'></option></select>";
                   echo "<select name='mac_adres' class='asen'><option value='NULL'></option></select>";
                   echo "<select name='pamet' class='asen'><option value='NULL'></option></select>";
                   echo "<select name='portove' class='asen'><option value='NULL'></option></select>";
                   echo "<select name='zahranvane' class='asen'><option value='NULL'></option></select>";
                   echo "<select name='harakteristika' class='asen'><option value='NULL'></option></select>";
                   echo "<select name='type' class='asen'><option value='" . $rows['type'] . "'></option></select>";
                       echo "<div class='back-face'>";
                       echo "<h2>" . $rows['ime'] . "</h2>";
                       echo "<select name='ime' class='asen'><option value='" . $rows['ime'] . "'></option></select>";

                       echo "<p>" . $rows['skorost'] ."</p>";
                       echo "<select name='skorost' class='asen'><option value='" . $rows['skorost'] . "'></option></select>";

                       echo "<p>" . $rows['sigurnost'] ."</p>";
                       echo "<select name='sigurnost' class='asen'><option value='" . $rows['sigurnost'] . "'></option></select>";

                       echo "<p>" . $rows['EAN'] ."</p>";
                       echo "<select name='EAN' class='asen'><option value='" . $rows['EAN'] . "'></option></select>";

                       echo "<p>" . $rows['cena'] ." лв.</p>";
                       echo "<select name='cena' class='asen'><option value='" . $rows['cena'] . "'><</option>/select>";

                       
                       echo "<input type ='submit' name = 'cartADD' class='itembtn' value = 'add'>";
                   echo "</div>";
                echo "</div>";
           echo "</div>";
           echo "</form>";
           echo "</div>";

           


}}
            }if($_GET["type"] == "switch"){
                require_once 'connectionProductDataBase.php';
                $q = "SELECT * FROM `switch`;";
                $r = mysqli_query($conP, $q);
                $rCheck = mysqli_num_rows($r);
                echo "<div class='filter'>";
                echo "<form action='filter.php' method='post'>";
                echo "<input type='radio' class='rdbtn' name='radioBtn' value='all' required>Всички";
                echo "<input type='radio' class='rdbtn' name='radioBtn' value='router' required>Рутери";
                echo "<input type='radio' class='rdbtn' name='radioBtn' value='switch' required>Суитчове";
                echo "<input type='radio' class='rdbtn' name='radioBtn' value='asus' required>Asus";
                echo "<input type='radio' class='rdbtn' name='radioBtn' value='huawei' required>Huawei";
                echo "<input type='radio' class='rdbtn' name='radioBtn' value='tp-link' required>tp-link";
                echo "<input type='radio' class='rdbtn' name='radioBtn' value='xiomi' required>xiomi";
                echo "<input type='radio' class='rdbtn' name='radioBtn' value='ZyXEL' required>ZyXL";
                echo "<input type='radio' class='rdbtn' name='radioBtn' value='dell' required>dell";
                echo "<input type='radio' class='rdbtn' name='radioBtn' value='cisco' required>cisco";
                echo "<div class='filter-button'>";
                echo "<input type='submit' name='submit' value='Филтрирай'>";
                echo "</div>";
                echo "</form>";
                echo "</div>";
                if($rCheck > 0){
                    while ($rows = mysqli_fetch_assoc($r)){
                     
        echo "<div class='card-container'>";
        echo "<form action='addtocart.php' method = 'post'>";
                   echo "<div class='card'>";
                       echo "<div class='card-inner'>";
                           echo "<div class='front-face'>";
                                echo "<img src='" . $rows['snimka'] . "'>";
                                echo "<select name='snimka' class='asen'><option value='" . $rows['snimka'] . "'></option></select>";
                           echo "</div>";
        
        
                               echo "<div class='back-face-switch'>";
                               echo "<h2>" . $rows['ime'] . "</h2>";
                               echo "<select name='ime' class='asen'><option value='" . $rows['ime'] . "'></option></select>";
                               echo "<select name='sigurnost' class='asen'><option value='NULL'></option></select>";
                               echo "<select name='skorost' class='asen'><option value='NULL'></option></select>";
                               echo "<select name='EAN' class='asen'><option value='NULL'></option></select>";
                               echo "<select name='harakteristika' class='asen'><option value='NULL'></option></select>";
        
                               echo "<p>" . $rows['portove'] . "</p>";
                               echo "<select name='portove' class='asen'><option value='" . $rows['portove'] . "'></option></select>";
        
                               echo "<p>" . $rows['zahranvane'] . "</p>";
                               echo "<select name='zahranvane' class='asen'><option value='" . $rows['zahranvane'] . "'></option></select>";
        
                               echo "<p>" . $rows['pamet'] . "</p>";
                               echo "<select name='pamet' class='asen'><option value='" . $rows['pamet'] . "'></option></select>";
        
                               echo "<p>" . $rows['kapacitet'] . "</p>";
                               echo "<select name='kapacitet' class='asen'><option value='" . $rows['kapacitet'] . "'></option></select>";
        
                               echo "<p>" . $rows['mac_adres'] . "</p>";
                               echo "<select name='mac_adres' class='asen'><option value='" . $rows['mac_adres'] . "'></option></select>";
                               
                               echo "<p class='cenaSwitch'>" . $rows['cena'] ." лв.</p>";
                               echo "<select name='cena' class='asen'><option value='" . $rows['cena'] . "'></option></select>";
        
                           echo "<input type ='submit' name = 'cartADD' class='itembtn' value = 'add'>";
                           echo "</div>";
                        echo "</div>";
                   echo "</div>";
                   echo "</form>";
                   echo "</div>";
        
                   
        
        
        }}
            } if($_GET["type"] == "all"){
                require_once 'connectionProductDataBase.php';
                $q = "SELECT * FROM `switch`;";
                $r = mysqli_query($conP, $q);
                $rCheck = mysqli_num_rows($r);

                echo "<div class='filter'>";
                echo "<form action='filter.php' method='post'>";
                echo "<input type='radio' class='rdbtn' name='radioBtn' value='all' required>Всички";
                echo "<input type='radio' class='rdbtn' name='radioBtn' value='router' required>Рутери";
                echo "<input type='radio' class='rdbtn' name='radioBtn' value='switch' required>Суитчове";
                echo "<input type='radio' class='rdbtn' name='radioBtn' value='asus' required>Asus";
                echo "<input type='radio' class='rdbtn' name='radioBtn' value='huawei' required>Huawei";
                echo "<input type='radio' class='rdbtn' name='radioBtn' value='tp-link' required>tp-link";
                echo "<input type='radio' class='rdbtn' name='radioBtn' value='xiomi' required>xiomi";
                echo "<input type='radio' class='rdbtn' name='radioBtn' value='ZyXEL' required>ZyXL";
                echo "<input type='radio' class='rdbtn' name='radioBtn' value='dell' required>dell";
                echo "<input type='radio' class='rdbtn' name='radioBtn' value='cisco' required>cisco";
                echo "<div class='filter-button'>";
                echo "<input type='submit' name='submit' value='Филтрирай'>";
                echo "</div>";
                echo "</form>";
                echo "</div>";
                if($rCheck > 0){
                    while ($rows = mysqli_fetch_assoc($r)){
                     
        echo "<div class='card-container'>";
        echo "<form action='addtocart.php' method = 'post'>";
                   echo "<div class='card'>";
                       echo "<div class='card-inner'>";
                           echo "<div class='front-face'>";
                                echo "<img src='" . $rows['snimka'] . "'>";
                                echo "<select name='snimka' class='asen'><option value='" . $rows['snimka'] . "'></option></select>";
                           echo "</div>";       
                               echo "<div class='back-face-switch'>";
                               echo "<h2>" . $rows['ime'] . "</h2>";
                               echo "<select name='ime' class='asen'><option value='" . $rows['ime'] . "'></option></select>";
                               echo "<select name='sigurnost' class='asen'><option value='NULL'></option></select>";
                               echo "<select name='skorost' class='asen'><option value='NULL'></option></select>";
                               echo "<select name='EAN' class='asen'><option value='NULL'></option></select>";       
                               echo "<p>" . $rows['portove'] . "</p>";
                               echo "<select name='portove' class='asen'><option value='" . $rows['portove'] . "'></option></select>";      
                               echo "<p>" . $rows['zahranvane'] . "</p>";
                               echo "<select name='zahranvane' class='asen'><option value='" . $rows['zahranvane'] . "'></option></select>";       
                               echo "<p>" . $rows['pamet'] . "</p>";
                               echo "<select name='pamet' class='asen'><option value='" . $rows['pamet'] . "'></option></select>";       
                               echo "<p>" . $rows['kapacitet'] . "</p>";
                               echo "<select name='kapacitet' class='asen'><option value='" . $rows['kapacitet'] . "'></option></select>";
                               echo "<p>" . $rows['mac_adres'] . "</p>";
                               echo "<select name='mac_adres' class='asen'><option value='" . $rows['mac_adres'] . "'></option></select>";
                               echo "<p class='cenaSwitch'>" . $rows['cena'] ." лв.</p>";
                               echo "<select name='cena' class='asen'><option value='" . $rows['cena'] . "'></option></select>";
                           echo "<input type ='submit' name = 'cartADD' class='itembtn' value = 'add'>";
                           echo "</div>";
                        echo "</div>";
                   echo "</div>";
                   echo "</form>";
                   echo "</div>";
        
                   
        
        
        }}
        require_once 'connectionProductDataBase.php';
        $q = "SELECT * FROM `router`;";
        $r = mysqli_query($conP, $q);
        $rCheck = mysqli_num_rows($r);

        
        if($rCheck > 0){
            while ($rows = mysqli_fetch_assoc($r)){
             
echo "<div class='card-container'>";
echo "<form action='addtocart.php' method = 'post'>";
           echo "<div class='card'>";
               echo "<div class='card-inner'>";
                   echo "<div class='front-face'>";
                        echo "<img src='" . $rows['snimka'] . "'>";
                        echo "<select name='snimka' class='asen'><option value='" . $rows['snimka'] . "'></option></select>";
                   echo "</div>";
                   echo "<select name='kapacitet' class='asen'><option value='NULL'></option></select>";
                   echo "<select name='mac_adres' class='asen'><option value='NULL'></option></select>";
                   echo "<select name='pamet' class='asen'><option value='NULL'></option></select>";
                   echo "<select name='portove' class='asen'><option value='NULL'></option></select>";
                   echo "<select name='zahranvane' class='asen'><option value='NULL'></option></select>";
                   echo "<select name='type' class='asen'><option value='" . $rows['type'] . "'></option></select>";
                       echo "<div class='back-face'>";
                       echo "<h2>" . $rows['ime'] . "</h2>";
                       echo "<select name='ime' class='asen'><option value='" . $rows['ime'] . "'></option></select>";

                       echo "<p>" . $rows['skorost'] ."</p>";
                       echo "<select name='skorost' class='asen'><option value='" . $rows['skorost'] . "'></option></select>";

                       echo "<p>" . $rows['sigurnost'] ."</p>";
                       echo "<select name='sigurnost' class='asen'><option value='" . $rows['sigurnost'] . "'></option></select>";

                       echo "<p>" . $rows['EAN'] ."</p>";
                       echo "<select name='EAN' class='asen'><option value='" . $rows['EAN'] . "'></option></select>";

                       echo "<p>" . $rows['cena'] ." лв.</p>";
                       echo "<select name='cena' class='asen'><option value='" . $rows['cena'] . "'><</option>/select>";

                       
                       echo "<input type ='submit' name = 'cartADD' class='itembtn' value = 'add'>";
                   echo "</div>";
                echo "</div>";
           echo "</div>";
           echo "</form>";
           echo "</div>";

           


}}
            }}
            if(isset($_GET["type"])){
                if($_GET["type"] == "asus"){
                    require_once 'connectionProductDataBase.php';
        $q = "SELECT * FROM `router` WHERE `marka` = 'ASUS';";
        $r = mysqli_query($conP, $q);
        $rCheck = mysqli_num_rows($r);
        echo "<div class='filter'>";
        echo "<form action='filter.php' method='post'>";
        echo "<input type='radio' class='rdbtn' name='radioBtn' value='all' required>Всички";
        echo "<input type='radio' class='rdbtn' name='radioBtn' value='router' required>Рутери";
        echo "<input type='radio' class='rdbtn' name='radioBtn' value='switch' required>Суитчове";
        echo "<input type='radio' class='rdbtn' name='radioBtn' value='asus' required>Asus";
        echo "<input type='radio' class='rdbtn' name='radioBtn' value='huawei' required>Huawei";
        echo "<input type='radio' class='rdbtn' name='radioBtn' value='tp-link' required>tp-link";
        echo "<input type='radio' class='rdbtn' name='radioBtn' value='xiomi' required>xiomi";
        echo "<input type='radio' class='rdbtn' name='radioBtn' value='ZyXEL' required>ZyXL";
        echo "<input type='radio' class='rdbtn' name='radioBtn' value='dell' required>dell";
        echo "<input type='radio' class='rdbtn' name='radioBtn' value='cisco' required>cisco";
        echo "<div class='filter-button'>";
        echo "<input type='submit' name='submit' value='Филтрирай'>";
        echo "</div>";
        echo "</form>";
        echo "</div>";
        if($rCheck > 0){
            while ($rows = mysqli_fetch_assoc($r)){
             
echo "<div class='card-container'>";
echo "<form action='addtocart.php' method = 'post'>";
           echo "<div class='card'>";
               echo "<div class='card-inner'>";
                   echo "<div class='front-face'>";
                        echo "<img src='" . $rows['snimka'] . "'>";
                        echo "<select name='snimka' class='asen'><option value='" . $rows['snimka'] . "'></option></select>";
                   echo "</div>";
                   echo "<select name='kapacitet' class='asen'><option value='NULL'></option></select>";
                   echo "<select name='mac_adres' class='asen'><option value='NULL'></option></select>";
                   echo "<select name='pamet' class='asen'><option value='NULL'></option></select>";
                   echo "<select name='portove' class='asen'><option value='NULL'></option></select>";
                   echo "<select name='zahranvane' class='asen'><option value='NULL'></option></select>";
                   echo "<select name='type' class='asen'><option value='" . $rows['type'] . "'></option></select>";
                       echo "<div class='back-face'>";
                       echo "<h2>" . $rows['ime'] . "</h2>";
                       echo "<select name='ime' class='asen'><option value='" . $rows['ime'] . "'></option></select>";

                       echo "<p>" . $rows['skorost'] ."</p>";
                       echo "<select name='skorost' class='asen'><option value='" . $rows['skorost'] . "'></option></select>";

                       echo "<p>" . $rows['sigurnost'] ."</p>";
                       echo "<select name='sigurnost' class='asen'><option value='" . $rows['sigurnost'] . "'></option></select>";

                       echo "<p>" . $rows['EAN'] ."</p>";
                       echo "<select name='EAN' class='asen'><option value='" . $rows['EAN'] . "'></option></select>";

                       echo "<p>" . $rows['cena'] ." лв.</p>";
                       echo "<select name='cena' class='asen'><option value='" . $rows['cena'] . "'><</option>/select>";

                       
                       echo "<input type ='submit' name = 'cartADD' class='itembtn' value = 'add'>";
                   echo "</div>";
                echo "</div>";
           echo "</div>";
           echo "</form>";
           echo "</div>";

           


}}
                    require_once 'connectionProductDataBase.php';
                $q = "SELECT * FROM `switch` WHERE `marka` = 'asus';";
                $r = mysqli_query($conP, $q);
                $rCheck = mysqli_num_rows($r);
             

                if($rCheck > 0){
                    while ($rows = mysqli_fetch_assoc($r)){
                     
        echo "<div class='card-container'>";
        echo "<form action='addtocart.php' method = 'post'>";
                   echo "<div class='card'>";
                       echo "<div class='card-inner'>";
                           echo "<div class='front-face'>";
                                echo "<img src='" . $rows['snimka'] . "'>";
                                echo "<select name='snimka' class='asen'><option value='" . $rows['snimka'] . "'></option></select>";
                           echo "</div>";
        
        
                               echo "<div class='back-face-switch'>";
                               echo "<h2>" . $rows['ime'] . "</h2>";
                               echo "<select name='ime' class='asen'><option value='" . $rows['ime'] . "'></option></select>";
                               echo "<select name='sigurnost' class='asen'><option value='NULL'></option></select>";
                               echo "<select name='skorost' class='asen'><option value='NULL'></option></select>";
                               echo "<select name='EAN' class='asen'><option value='NULL'></option></select>";
                               echo "<select name='harakteristika' class='asen'><option value='NULL'></option></select>";
        
                               echo "<p>" . $rows['portove'] . "</p>";
                               echo "<select name='portove' class='asen'><option value='" . $rows['portove'] . "'></option></select>";
        
                               echo "<p>" . $rows['zahranvane'] . "</p>";
                               echo "<select name='zahranvane' class='asen'><option value='" . $rows['zahranvane'] . "'></option></select>";
        
                               echo "<p>" . $rows['pamet'] . "</p>";
                               echo "<select name='pamet' class='asen'><option value='" . $rows['pamet'] . "'></option></select>";
        
                               echo "<p>" . $rows['kapacitet'] . "</p>";
                               echo "<select name='kapacitet' class='asen'><option value='" . $rows['kapacitet'] . "'></option></select>";
        
                               echo "<p>" . $rows['mac_adres'] . "</p>";
                               echo "<select name='mac_adres' class='asen'><option value='" . $rows['mac_adres'] . "'></option></select>";
                               
                               echo "<p class='cenaSwitch'>" . $rows['cena'] ." лв.</p>";
                               echo "<select name='cena' class='asen'><option value='" . $rows['cena'] . "'></option></select>";
        
                           echo "<input type ='submit' name = 'cartADD' class='itembtn' value = 'add'>";
                           echo "</div>";
                        echo "</div>";
                   echo "</div>";
                   echo "</form>";
                   echo "</div>";
        
                   
        
        
        }}
                }
                if($_GET["type"] == "huawei"){
                    require_once 'connectionProductDataBase.php';
        $q = "SELECT * FROM `router` WHERE `marka` = 'Huawei';";
        $r = mysqli_query($conP, $q);
        $rCheck = mysqli_num_rows($r);
        echo "<div class='filter'>";
        echo "<form action='filter.php' method='post'>";
        echo "<input type='radio' class='rdbtn' name='radioBtn' value='all' required>Всички";
        echo "<input type='radio' class='rdbtn' name='radioBtn' value='router' required>Рутери";
        echo "<input type='radio' class='rdbtn' name='radioBtn' value='switch' required>Суитчове";
        echo "<input type='radio' class='rdbtn' name='radioBtn' value='asus' required>Asus";
        echo "<input type='radio' class='rdbtn' name='radioBtn' value='huawei' required>Huawei";
        echo "<input type='radio' class='rdbtn' name='radioBtn' value='tp-link' required>tp-link";
        echo "<input type='radio' class='rdbtn' name='radioBtn' value='xiomi' required>xiomi";
        echo "<input type='radio' class='rdbtn' name='radioBtn' value='ZyXEL' required>ZyXL";
        echo "<input type='radio' class='rdbtn' name='radioBtn' value='dell' required>dell";
        echo "<input type='radio' class='rdbtn' name='radioBtn' value='cisco' required>cisco";
        echo "<div class='filter-button'>";
        echo "<input type='submit' name='submit' value='Филтрирай'>";
        echo "</div>";
        echo "</form>";
        echo "</div>";
        if($rCheck > 0){
            while ($rows = mysqli_fetch_assoc($r)){
             
echo "<div class='card-container'>";
echo "<form action='addtocart.php' method = 'post'>";
           echo "<div class='card'>";
               echo "<div class='card-inner'>";
                   echo "<div class='front-face'>";
                        echo "<img src='" . $rows['snimka'] . "'>";
                        echo "<select name='snimka' class='asen'><option value='" . $rows['snimka'] . "'></option></select>";
                   echo "</div>";
                   echo "<select name='kapacitet' class='asen'><option value='NULL'></option></select>";
                   echo "<select name='mac_adres' class='asen'><option value='NULL'></option></select>";
                   echo "<select name='pamet' class='asen'><option value='NULL'></option></select>";
                   echo "<select name='portove' class='asen'><option value='NULL'></option></select>";
                   echo "<select name='zahranvane' class='asen'><option value='NULL'></option></select>";
                   echo "<select name='type' class='asen'><option value='" . $rows['type'] . "'></option></select>";
                       echo "<div class='back-face'>";
                       echo "<h2>" . $rows['ime'] . "</h2>";
                       echo "<select name='ime' class='asen'><option value='" . $rows['ime'] . "'></option></select>";

                       echo "<p>" . $rows['skorost'] ."</p>";
                       echo "<select name='skorost' class='asen'><option value='" . $rows['skorost'] . "'></option></select>";

                       echo "<p>" . $rows['sigurnost'] ."</p>";
                       echo "<select name='sigurnost' class='asen'><option value='" . $rows['sigurnost'] . "'></option></select>";

                       echo "<p>" . $rows['EAN'] ."</p>";
                       echo "<select name='EAN' class='asen'><option value='" . $rows['EAN'] . "'></option></select>";

                       echo "<p>" . $rows['cena'] ." лв.</p>";
                       echo "<select name='cena' class='asen'><option value='" . $rows['cena'] . "'><</option>/select>";

                       
                       echo "<input type ='submit' name = 'cartADD' class='itembtn' value = 'add'>";
                   echo "</div>";
                echo "</div>";
           echo "</div>";
           echo "</form>";
           echo "</div>";

           


}}
                }
                if($_GET["type"] == "tp-link"){
                    require_once 'connectionProductDataBase.php';
        $q = "SELECT * FROM `router` WHERE `marka` = 'TP-LINK';";
        $r = mysqli_query($conP, $q);
        $rCheck = mysqli_num_rows($r);
        echo "<div class='filter'>";
        echo "<form action='filter.php' method='post'>";
        echo "<input type='radio' class='rdbtn' name='radioBtn' value='all' required>Всички";
        echo "<input type='radio' class='rdbtn' name='radioBtn' value='router' required>Рутери";
        echo "<input type='radio' class='rdbtn' name='radioBtn' value='switch' required>Суитчове";
        echo "<input type='radio' class='rdbtn' name='radioBtn' value='asus' required>Asus";
        echo "<input type='radio' class='rdbtn' name='radioBtn' value='huawei' required>Huawei";
        echo "<input type='radio' class='rdbtn' name='radioBtn' value='tp-link' required>tp-link";
        echo "<input type='radio' class='rdbtn' name='radioBtn' value='xiomi' required>xiomi";
        echo "<input type='radio' class='rdbtn' name='radioBtn' value='ZyXEL' required>ZyXL";
        echo "<input type='radio' class='rdbtn' name='radioBtn' value='dell' required>dell";
        echo "<input type='radio' class='rdbtn' name='radioBtn' value='cisco' required>cisco";
        echo "<div class='filter-button'>";
        echo "<input type='submit' name='submit' value='Филтрирай'>";
        echo "</div>";
        echo "</form>";
        echo "</div>";
        if($rCheck > 0){
            while ($rows = mysqli_fetch_assoc($r)){
             
echo "<div class='card-container'>";
echo "<form action='addtocart.php' method = 'post'>";
           echo "<div class='card'>";
               echo "<div class='card-inner'>";
                   echo "<div class='front-face'>";
                        echo "<img src='" . $rows['snimka'] . "'>";
                        echo "<select name='snimka' class='asen'><option value='" . $rows['snimka'] . "'></option></select>";
                   echo "</div>";
                   echo "<select name='kapacitet' class='asen'><option value='NULL'></option></select>";
                   echo "<select name='mac_adres' class='asen'><option value='NULL'></option></select>";
                   echo "<select name='pamet' class='asen'><option value='NULL'></option></select>";
                   echo "<select name='portove' class='asen'><option value='NULL'></option></select>";
                   echo "<select name='zahranvane' class='asen'><option value='NULL'></option></select>";
                   echo "<select name='type' class='asen'><option value='" . $rows['type'] . "'></option></select>";
                       echo "<div class='back-face'>";
                       echo "<h2>" . $rows['ime'] . "</h2>";
                       echo "<select name='ime' class='asen'><option value='" . $rows['ime'] . "'></option></select>";

                       echo "<p>" . $rows['skorost'] ."</p>";
                       echo "<select name='skorost' class='asen'><option value='" . $rows['skorost'] . "'></option></select>";

                       echo "<p>" . $rows['sigurnost'] ."</p>";
                       echo "<select name='sigurnost' class='asen'><option value='" . $rows['sigurnost'] . "'></option></select>";

                       echo "<p>" . $rows['EAN'] ."</p>";
                       echo "<select name='EAN' class='asen'><option value='" . $rows['EAN'] . "'></option></select>";

                       echo "<p>" . $rows['cena'] ." лв.</p>";
                       echo "<select name='cena' class='asen'><option value='" . $rows['cena'] . "'><</option>/select>";

                       
                       echo "<input type ='submit' name = 'cartADD' class='itembtn' value = 'add'>";
                   echo "</div>";
                echo "</div>";
           echo "</div>";
           echo "</form>";
           echo "</div>";

           


}}
                }
                if($_GET["type"] == "xiomi"){
                    require_once 'connectionProductDataBase.php';
        $q = "SELECT * FROM `router` WHERE `marka` = 'XIAOMI';";
        $r = mysqli_query($conP, $q);
        $rCheck = mysqli_num_rows($r);
        echo "<div class='filter'>";
        echo "<form action='filter.php' method='post'>";
        echo "<input type='radio' class='rdbtn' name='radioBtn' value='all' required>Всички";
        echo "<input type='radio' class='rdbtn' name='radioBtn' value='router' required>Рутери";
        echo "<input type='radio' class='rdbtn' name='radioBtn' value='switch' required>Суитчове";
        echo "<input type='radio' class='rdbtn' name='radioBtn' value='asus' required>Asus";
        echo "<input type='radio' class='rdbtn' name='radioBtn' value='huawei' required>Huawei";
        echo "<input type='radio' class='rdbtn' name='radioBtn' value='tp-link' required>tp-link";
        echo "<input type='radio' class='rdbtn' name='radioBtn' value='xiomi' required>xiomi";
        echo "<input type='radio' class='rdbtn' name='radioBtn' value='ZyXEL' required>ZyXL";
        echo "<input type='radio' class='rdbtn' name='radioBtn' value='dell' required>dell";
        echo "<input type='radio' class='rdbtn' name='radioBtn' value='cisco' required>cisco";
        echo "<div class='filter-button'>";
        echo "<input type='submit' name='submit' value='Филтрирай'>";
        echo "</div>";
        echo "</form>";
        echo "</div>";
        if($rCheck > 0){
            while ($rows = mysqli_fetch_assoc($r)){
             
echo "<div class='card-container'>";
echo "<form action='addtocart.php' method = 'post'>";
           echo "<div class='card'>";
               echo "<div class='card-inner'>";
                   echo "<div class='front-face'>";
                        echo "<img src='" . $rows['snimka'] . "'>";
                        echo "<select name='snimka' class='asen'><option value='" . $rows['snimka'] . "'></option></select>";
                   echo "</div>";
                   echo "<select name='kapacitet' class='asen'><option value='NULL'></option></select>";
                   echo "<select name='mac_adres' class='asen'><option value='NULL'></option></select>";
                   echo "<select name='pamet' class='asen'><option value='NULL'></option></select>";
                   echo "<select name='portove' class='asen'><option value='NULL'></option></select>";
                   echo "<select name='zahranvane' class='asen'><option value='NULL'></option></select>";
                   echo "<select name='type' class='asen'><option value='" . $rows['type'] . "'></option></select>";
                       echo "<div class='back-face'>";
                       echo "<h2>" . $rows['ime'] . "</h2>";
                       echo "<select name='ime' class='asen'><option value='" . $rows['ime'] . "'></option></select>";

                       echo "<p>" . $rows['skorost'] ."</p>";
                       echo "<select name='skorost' class='asen'><option value='" . $rows['skorost'] . "'></option></select>";

                       echo "<p>" . $rows['sigurnost'] ."</p>";
                       echo "<select name='sigurnost' class='asen'><option value='" . $rows['sigurnost'] . "'></option></select>";

                       echo "<p>" . $rows['EAN'] ."</p>";
                       echo "<select name='EAN' class='asen'><option value='" . $rows['EAN'] . "'></option></select>";

                       echo "<p>" . $rows['cena'] ." лв.</p>";
                       echo "<select name='cena' class='asen'><option value='" . $rows['cena'] . "'><</option>/select>";

                       
                       echo "<input type ='submit' name = 'cartADD' class='itembtn' value = 'add'>";
                   echo "</div>";
                echo "</div>";
           echo "</div>";
           echo "</form>";
           echo "</div>";

           


}}
                }
                if($_GET["type"] == "ZyXEL"){
                    require_once 'connectionProductDataBase.php';
        $q = "SELECT * FROM `router` WHERE `marka` = 'ZyXEL';";
        $r = mysqli_query($conP, $q);
        $rCheck = mysqli_num_rows($r);
        echo "<div class='filter'>";
        echo "<form action='filter.php' method='post'>";
        echo "<input type='radio' class='rdbtn' name='radioBtn' value='all' required>Всички";
        echo "<input type='radio' class='rdbtn' name='radioBtn' value='router' required>Рутери";
        echo "<input type='radio' class='rdbtn' name='radioBtn' value='switch' required>Суитчове";
        echo "<input type='radio' class='rdbtn' name='radioBtn' value='asus' required>Asus";
        echo "<input type='radio' class='rdbtn' name='radioBtn' value='huawei' required>Huawei";
        echo "<input type='radio' class='rdbtn' name='radioBtn' value='tp-link' required>tp-link";
        echo "<input type='radio' class='rdbtn' name='radioBtn' value='xiomi' required>xiomi";
        echo "<input type='radio' class='rdbtn' name='radioBtn' value='ZyXEL' required>ZyXL";
        echo "<input type='radio' class='rdbtn' name='radioBtn' value='dell' required>dell";
        echo "<input type='radio' class='rdbtn' name='radioBtn' value='cisco' required>cisco";
        echo "<div class='filter-button'>";
        echo "<input type='submit' name='submit' value='Филтрирай'>";
        echo "</div>";
        echo "</form>";
        echo "</div>";
        if($rCheck > 0){
            while ($rows = mysqli_fetch_assoc($r)){
             
echo "<div class='card-container'>";
echo "<form action='addtocart.php' method = 'post'>";
           echo "<div class='card'>";
               echo "<div class='card-inner'>";
                   echo "<div class='front-face'>";
                        echo "<img src='" . $rows['snimka'] . "'>";
                        echo "<select name='snimka' class='asen'><option value='" . $rows['snimka'] . "'></option></select>";
                   echo "</div>";
                   echo "<select name='kapacitet' class='asen'><option value='NULL'></option></select>";
                   echo "<select name='mac_adres' class='asen'><option value='NULL'></option></select>";
                   echo "<select name='pamet' class='asen'><option value='NULL'></option></select>";
                   echo "<select name='portove' class='asen'><option value='NULL'></option></select>";
                   echo "<select name='zahranvane' class='asen'><option value='NULL'></option></select>";
                   echo "<select name='type' class='asen'><option value='" . $rows['type'] . "'></option></select>";
                       echo "<div class='back-face'>";
                       echo "<h2>" . $rows['ime'] . "</h2>";
                       echo "<select name='ime' class='asen'><option value='" . $rows['ime'] . "'></option></select>";

                       echo "<p>" . $rows['skorost'] ."</p>";
                       echo "<select name='skorost' class='asen'><option value='" . $rows['skorost'] . "'></option></select>";

                       echo "<p>" . $rows['sigurnost'] ."</p>";
                       echo "<select name='sigurnost' class='asen'><option value='" . $rows['sigurnost'] . "'></option></select>";

                       echo "<p>" . $rows['EAN'] ."</p>";
                       echo "<select name='EAN' class='asen'><option value='" . $rows['EAN'] . "'></option></select>";

                       echo "<p>" . $rows['cena'] ." лв.</p>";
                       echo "<select name='cena' class='asen'><option value='" . $rows['cena'] . "'><</option>/select>";

                       
                       echo "<input type ='submit' name = 'cartADD' class='itembtn' value = 'add'>";
                   echo "</div>";
                echo "</div>";
           echo "</div>";
           echo "</form>";
           echo "</div>";

           


}}

                    require_once 'connectionProductDataBase.php';
                $q = "SELECT * FROM `switch` WHERE `marka` = 'ZyXEL';";
                $r = mysqli_query($conP, $q);
                $rCheck = mysqli_num_rows($r);
                if($rCheck > 0){
                    while ($rows = mysqli_fetch_assoc($r)){
                     
        echo "<div class='card-container'>";
        echo "<form action='addtocart.php' method = 'post'>";
                   echo "<div class='card'>";
                       echo "<div class='card-inner'>";
                           echo "<div class='front-face'>";
                                echo "<img src='" . $rows['snimka'] . "'>";
                                echo "<select name='snimka' class='asen'><option value='" . $rows['snimka'] . "'></option></select>";
                           echo "</div>";
        
        
                               echo "<div class='back-face-switch'>";
                               echo "<h2>" . $rows['ime'] . "</h2>";
                               echo "<select name='ime' class='asen'><option value='" . $rows['ime'] . "'></option></select>";
                               echo "<select name='sigurnost' class='asen'><option value='NULL'></option></select>";
                               echo "<select name='skorost' class='asen'><option value='NULL'></option></select>";
                               echo "<select name='EAN' class='asen'><option value='NULL'></option></select>";
                               echo "<select name='harakteristika' class='asen'><option value='NULL'></option></select>";
        
                               echo "<p>" . $rows['portove'] . "</p>";
                               echo "<select name='portove' class='asen'><option value='" . $rows['portove'] . "'></option></select>";
        
                               echo "<p>" . $rows['zahranvane'] . "</p>";
                               echo "<select name='zahranvane' class='asen'><option value='" . $rows['zahranvane'] . "'></option></select>";
        
                               echo "<p>" . $rows['pamet'] . "</p>";
                               echo "<select name='pamet' class='asen'><option value='" . $rows['pamet'] . "'></option></select>";
        
                               echo "<p>" . $rows['kapacitet'] . "</p>";
                               echo "<select name='kapacitet' class='asen'><option value='" . $rows['kapacitet'] . "'></option></select>";
        
                               echo "<p>" . $rows['mac_adres'] . "</p>";
                               echo "<select name='mac_adres' class='asen'><option value='" . $rows['mac_adres'] . "'></option></select>";
                               
                               echo "<p class='cenaSwitch'>" . $rows['cena'] ." лв.</p>";
                               echo "<select name='cena' class='asen'><option value='" . $rows['cena'] . "'></option></select>";
        
                           echo "<input type ='submit' name = 'cartADD' class='itembtn' value = 'add'>";
                           echo "</div>";
                        echo "</div>";
                   echo "</div>";
                   echo "</form>";
                   echo "</div>";
        
                   
        
        
        }}
                }
                if($_GET["type"] == "dell"){
                    require_once 'connectionProductDataBase.php';
                $q = "SELECT * FROM `switch` WHERE `marka` = 'dell';";
                $r = mysqli_query($conP, $q);
                $rCheck = mysqli_num_rows($r);
                echo "<div class='filter'>";
                echo "<form action='filter.php' method='post'>";
                echo "<input type='radio' class='rdbtn' name='radioBtn' value='all' required>Всички";
                echo "<input type='radio' class='rdbtn' name='radioBtn' value='router' required>Рутери";
                echo "<input type='radio' class='rdbtn' name='radioBtn' value='switch' required>Суитчове";
                echo "<input type='radio' class='rdbtn' name='radioBtn' value='asus' required>Asus";
                echo "<input type='radio' class='rdbtn' name='radioBtn' value='huawei' required>Huawei";
                echo "<input type='radio' class='rdbtn' name='radioBtn' value='tp-link' required>tp-link";
                echo "<input type='radio' class='rdbtn' name='radioBtn' value='xiomi' required>xiomi";
                echo "<input type='radio' class='rdbtn' name='radioBtn' value='ZyXEL' required>ZyXL";
                echo "<input type='radio' class='rdbtn' name='radioBtn' value='dell' required>dell";
                echo "<input type='radio' class='rdbtn' name='radioBtn' value='cisco' required>cisco";
                echo "<div class='filter-button'>";
                echo "<input type='submit' name='submit' value='Филтрирай'>";
                echo "</div>";
                echo "</form>";
                echo "</div>";
                if($rCheck > 0){
                    while ($rows = mysqli_fetch_assoc($r)){
                     
        echo "<div class='card-container'>";
        echo "<form action='addtocart.php' method = 'post'>";
                   echo "<div class='card'>";
                       echo "<div class='card-inner'>";
                           echo "<div class='front-face'>";
                                echo "<img src='" . $rows['snimka'] . "'>";
                                echo "<select name='snimka' class='asen'><option value='" . $rows['snimka'] . "'></option></select>";
                           echo "</div>";
        
        
                               echo "<div class='back-face-switch'>";
                               echo "<h2>" . $rows['ime'] . "</h2>";
                               echo "<select name='ime' class='asen'><option value='" . $rows['ime'] . "'></option></select>";
                               echo "<select name='sigurnost' class='asen'><option value='NULL'></option></select>";
                               echo "<select name='skorost' class='asen'><option value='NULL'></option></select>";
                               echo "<select name='EAN' class='asen'><option value='NULL'></option></select>";
                               echo "<select name='harakteristika' class='asen'><option value='NULL'></option></select>";
        
                               echo "<p>" . $rows['portove'] . "</p>";
                               echo "<select name='portove' class='asen'><option value='" . $rows['portove'] . "'></option></select>";
        
                               echo "<p>" . $rows['zahranvane'] . "</p>";
                               echo "<select name='zahranvane' class='asen'><option value='" . $rows['zahranvane'] . "'></option></select>";
        
                               echo "<p>" . $rows['pamet'] . "</p>";
                               echo "<select name='pamet' class='asen'><option value='" . $rows['pamet'] . "'></option></select>";
        
                               echo "<p>" . $rows['kapacitet'] . "</p>";
                               echo "<select name='kapacitet' class='asen'><option value='" . $rows['kapacitet'] . "'></option></select>";
        
                               echo "<p>" . $rows['mac_adres'] . "</p>";
                               echo "<select name='mac_adres' class='asen'><option value='" . $rows['mac_adres'] . "'></option></select>";
                               
                               echo "<p class='cenaSwitch'>" . $rows['cena'] ." лв.</p>";
                               echo "<select name='cena' class='asen'><option value='" . $rows['cena'] . "'></option></select>";
        
                           echo "<input type ='submit' name = 'cartADD' class='itembtn' value = 'add'>";
                           echo "</div>";
                        echo "</div>";
                   echo "</div>";
                   echo "</form>";
                   echo "</div>";
        
                   
        
        
        }}
                }
                if($_GET["type"] == "cisco"){
                    require_once 'connectionProductDataBase.php';
                $q = "SELECT * FROM `switch` WHERE `marka` = 'cisco';";
                $r = mysqli_query($conP, $q);
                $rCheck = mysqli_num_rows($r);
                echo "<div class='filter'>";
                echo "<form action='filter.php' method='post'>";
                echo "<form action='filter.php' method='post'>";
                echo "<input type='radio' class='rdbtn' name='radioBtn' value='all' required>Всички";
                echo "<input type='radio' class='rdbtn' name='radioBtn' value='router' required>Рутери";
                echo "<input type='radio' class='rdbtn' name='radioBtn' value='switch' required>Суитчове";
                echo "<input type='radio' class='rdbtn' name='radioBtn' value='asus' required>Asus";
                echo "<input type='radio' class='rdbtn' name='radioBtn' value='huawei' required>Huawei";
                echo "<input type='radio' class='rdbtn' name='radioBtn' value='tp-link' required>tp-link";
                echo "<input type='radio' class='rdbtn' name='radioBtn' value='xiomi' required>xiomi";
                echo "<input type='radio' class='rdbtn' name='radioBtn' value='ZyXEL' required>ZyXL";
                echo "<input type='radio' class='rdbtn' name='radioBtn' value='dell' required>dell";
                echo "<input type='radio' class='rdbtn' name='radioBtn' value='cisco' required>cisco";
                echo "<div class='filter-button'>";
                echo "<input type='submit' name='submit' value='Филтрирай'>";
                echo "</div>";
                echo "</form>";
                echo "</div>";
                if($rCheck > 0){
                    while ($rows = mysqli_fetch_assoc($r)){
                     
        echo "<div class='card-container'>";
        echo "<form action='addtocart.php' method = 'post'>";
                   echo "<div class='card'>";
                       echo "<div class='card-inner'>";
                           echo "<div class='front-face'>";
                                echo "<img src='" . $rows['snimka'] . "'>";
                                echo "<select name='snimka' class='asen'><option value='" . $rows['snimka'] . "'></option></select>";
                           echo "</div>";
        
        
                               echo "<div class='back-face-switch'>";
                               echo "<h2>" . $rows['ime'] . "</h2>";
                               echo "<select name='ime' class='asen'><option value='" . $rows['ime'] . "'></option></select>";
                               echo "<select name='sigurnost' class='asen'><option value='NULL'></option></select>";
                               echo "<select name='skorost' class='asen'><option value='NULL'></option></select>";
                               echo "<select name='EAN' class='asen'><option value='NULL'></option></select>";
                               echo "<select name='harakteristika' class='asen'><option value='NULL'></option></select>";
        
                               echo "<p>" . $rows['portove'] . "</p>";
                               echo "<select name='portove' class='asen'><option value='" . $rows['portove'] . "'></option></select>";
        
                               echo "<p>" . $rows['zahranvane'] . "</p>";
                               echo "<select name='zahranvane' class='asen'><option value='" . $rows['zahranvane'] . "'></option></select>";
        
                               echo "<p>" . $rows['pamet'] . "</p>";
                               echo "<select name='pamet' class='asen'><option value='" . $rows['pamet'] . "'></option></select>";
        
                               echo "<p>" . $rows['kapacitet'] . "</p>";
                               echo "<select name='kapacitet' class='asen'><option value='" . $rows['kapacitet'] . "'></option></select>";
        
                               echo "<p>" . $rows['mac_adres'] . "</p>";
                               echo "<select name='mac_adres' class='asen'><option value='" . $rows['mac_adres'] . "'></option></select>";
                               
                               echo "<p class='cenaSwitch'>" . $rows['cena'] ." лв.</p>";
                               echo "<select name='cena' class='asen'><option value='" . $rows['cena'] . "'></option></select>";
        
                           echo "<input type ='submit' name = 'cartADD' class='itembtn' value = 'add'>";
                           echo "</div>";
                        echo "</div>";
                   echo "</div>";
                   echo "</form>";
                   echo "</div>";
        
                   
        
        
        }}
                }
            }
            if($_GET["type"] == "notlogged"){
                header("location: login.php");
exit();
            }

        ?>



    <!-- <div class="big-container">
        <div class="card-container">
            <div class="card" id="item1">
                <div class="card-inner">
                    <div class="front-face">
                        <img src="products/asus/ASUS RT-AC58U AC1200.jpg">k
                    </div>
                    <div class="back-face">
                        <h2 id="title">ASUS RT-AC58U AC1200</h2>
                        <p>HARAKTERISTIKA</p>
                    <a onclick="addToCard(item1)" class="itembtn">ADD</a>
                    
                    </div>
                </div>
            </div>
        </div>
        <div class="card-container">
            <div class="card" id="item2">
                <div class="card-inner">
                    <div class="front-face">
                        <img src="products/asus/ASUS RT-AX55 AX1800.jpg">
                    </div>
                    <div class="back-face">
                        <h2>ASUS RT-AX55 AX1800</h2>
                        <p>HARAKTERISTIKA</p>
                    <a onclick="addToCard(item2)" class="itembtn">ADD</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="card-container">
            <div class="card">
                <div class="card-inner">
                    <div class="front-face">
                        <img src="products/asus/ASUS TUF-AX5400.jpg">
                    </div>
                    <div class="back-face">
                        <h2>ASUS TUF-AX5400</h2>
                        <p>HARAKTERISTIKA</p>
                    <a href="#" class="itembtn">ADD</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="card-container">
            <div class="card">
                <div class="card-inner">
                    <div class="front-face">
                        <img src="products/huawei/Huawei - AX3.jpg">
                    </div>
                    <div class="back-face">
                        <h2>Huawei - AX3</h2>
                        <p>HARAKTERISTIKA</p>
                    <a href="#" class="itembtn">ADD</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="card-container">
            <div class="card">
                <div class="card-inner">
                    <div class="front-face">
                        <img src="products/huawei/Huawei - AX3 Pro.jpg">
                    </div>
                    <div class="back-face">
                        <h2>Huawei - AX3 Pro</h2>
                        <p>HARAKTERISTIKA</p>
                    <a href="#" class="itembtn">ADD</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="big-container">
        <div class="card-container">
            <div class="card" id="item1">
                <div class="card-inner">
                    <div class="front-face">
                        <img src="products/tp-link/TP-LINK ARCHER A5 AC1200.jpg">
                    </div>
                    <div class="back-face">
                        <h2 id="title">TP-LINK ARCHER A5 AC1200</h2>
                        <p>HARAKTERISTIKA</p>
                    <a onclick="addToCard(item1)" class="itembtn">ADD</a>
                    
                    </div>
                </div>
            </div>
        </div>
        <div class="card-container">
            <div class="card" id="item2">
                <div class="card-inner">
                    <div class="front-face">
                        <img src="products/tp-link/TP-LINK ARCHER AX73AX5400.jpg">
                    </div>
                    <div class="back-face">
                        <h2>TP-LINK ARCHER AX73AX5400</h2>
                        <p>HARAKTERISTIKA</p>
                    <a onclick="addToCard(item2)" class="itembtn">ADD</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="card-container">
            <div class="card">
                <div class="card-inner">
                    <div class="front-face">
                        <img src="products/tp-link/TP-LINK ARCHER C20 750.jpg">
                    </div>
                    <div class="back-face">
                        <h2>TP-LINK ARCHER C20 750</h2>
                        <p>HARAKTERISTIKA</p>
                    <a href="#" class="itembtn">ADD</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="card-container">
            <div class="card">
                <div class="card-inner">
                    <div class="front-face">
                        <img src="products/tp-link/TP-LINK ARCHER C54.jpg">
                    </div>
                    <div class="back-face">
                        <h2>TP-LINK ARCHER C54</h2>
                        <p>HARAKTERISTIKA</p>
                    <a href="#" class="itembtn">ADD</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="card-container">
            <div class="card">
                <div class="card-inner">
                    <div class="front-face">
                        <img src="products/tp-link/TP-LINK ARCHER C1200.jpg">
                    </div>
                    <div class="back-face">
                        <h2>TP-LINK ARCHER C1200</h2>
                        <p>HARAKTERISTIKA</p>
                    <a href="#" class="itembtn">ADD</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="big-container">
        <div class="card-container">
            <div class="card" id="item1">
                <div class="card-inner">
                    <div class="front-face">
                        <img src="products/tp-link/TP-LINK TL-MR3420 4G.jpg">
                    </div>
                    <div class="back-face">
                        <h2 id="title">TP-LINK TL-MR3420 4G</h2>
                        <p>HARAKTERISTIKA</p>
                    <a onclick="addToCard(item1)" class="itembtn">ADD</a>
                    
                    </div>
                </div>
            </div>
        </div>
        <div class="card-container">
            <div class="card" id="item2">
                <div class="card-inner">
                    <div class="front-face">
                        <img src="products/tp-link/TP-LINK WR841N.jpg">
                    </div>
                    <div class="back-face">
                        <h2>TP-LINK WR841N</h2>
                        <p>HARAKTERISTIKA</p>
                    <a onclick="addToCard(item2)" class="itembtn">ADD</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="card-container">
            <div class="card">
                <div class="card-inner">
                    <div class="front-face">
                        <img src="products/xiomi/XIAOMI MI 4A.jpg">
                    </div>
                    <div class="back-face">
                        <h2>XIAOMI MI 4A</h2>
                        <p>HARAKTERISTIKA</p>
                    <a href="#" class="itembtn">ADD</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="card-container">
            <div class="card">
                <div class="card-inner">
                    <div class="front-face">
                        <img src="products/xiomi/XIAOMI MI AX1800.jpg">
                    </div>
                    <div class="back-face">
                        <h2>XIAOMI MI AX1800</h2>
                        <p>HARAKTERISTIKA</p>
                    <a href="#" class="itembtn">ADD</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="card-container">
            <div class="card">
                <div class="card-inner">
                    <div class="front-face">
                        <img src="products/ZyXEL/ZyXEL - NBG6604.jpg">
                    </div>
                    <div class="back-face">
                        <h2>ZyXEL - NBG6604</h2>
                        <p>HARAKTERISTIKA</p>
                    <a href="#" class="itembtn">ADD</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="big-container">
        <div class="card-container">
            <div class="card" id="item1">
                <div class="card-inner">
                    <div class="front-face">
                        <img src="products/ZyXEL/ZyXEL NBG6816.png">
                    </div>
                    <div class="back-face">
                        <h2 id="title">ZyXEL NBG6816</h2>
                        <p>HARAKTERISTIKA</p>
                    <a onclick="addToCard(item1)" class="itembtn">ADD</a>
                    
                    </div>
                </div>
            </div>
        </div> -->
    
</body>