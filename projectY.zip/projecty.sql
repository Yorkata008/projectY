-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1
-- Време на генериране:  8 авг 2022 в 17:52
-- Версия на сървъра: 10.4.22-MariaDB
-- Версия на PHP: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данни: `projecty`
--

-- --------------------------------------------------------

--
-- Структура на таблица `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `ime` varchar(200) NOT NULL,
  `harakteristika` varchar(250) NOT NULL,
  `marka` varchar(200) NOT NULL,
  `sigurnost` varchar(200) NOT NULL,
  `skorost` varchar(200) NOT NULL,
  `snimka` varchar(200) NOT NULL,
  `type` varchar(200) NOT NULL,
  `cena` double NOT NULL,
  `EAN` varchar(200) NOT NULL,
  `kapacitet` varchar(200) NOT NULL,
  `mac_adres` varchar(200) NOT NULL,
  `pamet` varchar(200) NOT NULL,
  `portove` varchar(200) NOT NULL,
  `zahranvane` varchar(200) NOT NULL,
  `primID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Схема на данните от таблица `cart`
--

INSERT INTO `cart` (`id`, `ime`, `harakteristika`, `marka`, `sigurnost`, `skorost`, `snimka`, `type`, `cena`, `EAN`, `kapacitet`, `mac_adres`, `pamet`, `portove`, `zahranvane`, `primID`) VALUES
(10, 'Cisco CBS220 Smart', '', '', 'NULL', 'NULL', 'products/switch/ciscoSwitch/Cisco CBS220 Smart 48.jpeg', '', 1525, 'NULL', 'Капацитет за маршрутизиране\r\n10 Gbps', 'MAC адреси\r\nUp to 8 192 ', 'Памет\r\nFlash: 64 MB, CPU memory: 256 ', 'Общ брой портове\r\n52', 'Захранване\r\nInternal, 100-240 V, 50-60 Hz', 141),
(11, 'Cisco CBS220', '', '', 'NULL', 'NULL', 'products/switch/ciscoSwitch/cisco CBS220.jpeg', '', 769.99, 'NULL', 'Капацитет за маршрутизиране\r\n128 Gbps', 'MAC адреси\r\nUp to 8 192', '24x RJ-45 10/100/1000 Mbps', 'Общ брой портове\r\n28', 'Захранване\r\nInternal, 100-240 V, 50-60 Hz', 145),
(13, 'MobileY Y\r\n', '', '', 'NULL', 'NULL', 'photo/service.png', '', 40.99, 'NULL', 'NULL', 'NULL', 'NULL', 'NULL', 'NULL', 152);

-- --------------------------------------------------------

--
-- Структура на таблица `orders`
--

CREATE TABLE `orders` (
  `id` int(15) NOT NULL,
  `idNaPoruchka` int(15) NOT NULL,
  `ime` varchar(30) NOT NULL,
  `cena` int(30) NOT NULL,
  `userId` int(11) NOT NULL,
  `snimka` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Схема на данните от таблица `orders`
--

INSERT INTO `orders` (`id`, `idNaPoruchka`, `ime`, `cena`, `userId`, `snimka`) VALUES
(3, 2, 'Dell EMC S4128F-ON Switch', 11118, 1, 'products/switch/dellSwitch/Dell EMC S4128F-ON.jpeg'),
(4, 2, 'ASUS TUF-AX5400', 211, 1, 'products/asus/ASUS TUF-AX5400.jpg'),
(7, 6, 'MobileY Y\r\n', 41, 4, 'photo/service.png'),
(10, 0, 'imence', 0, 0, ''),
(11, 10, 'ASUS TUF-AX5400', 211, 4, 'products/asus/ASUS TUF-AX5400.jpg'),
(12, 10, 'Dell EMC N3248X-ON', 10713, 4, 'products/switch/dellSwitch/Dell EMC PowerSwitch N3'),
(14, 0, 'imence', 0, 0, ''),
(15, 14, 'MobileY Y\r\n', 41, 4, 'photo/service.png'),
(16, 0, 'imence', 0, 0, ''),
(17, 16, 'MobileY Y\r\n', 41, 4, 'photo/service.png'),
(18, 16, 'MobileY Y\r\n', 41, 4, 'photo/service.png'),
(19, 0, 'imence', 0, 0, ''),
(20, 19, 'Cisco CBS220', 770, 4, 'products/switch/ciscoSwitch/cisco CBS220.jpeg'),
(21, 19, 'ASUS TUF-AX5400', 211, 4, 'products/asus/ASUS TUF-AX5400.jpg'),
(22, 19, 'MobileY Y\r\n', 41, 4, 'photo/service.png'),
(23, 19, 'ZyXEL NBG6816', 178, 4, 'products/ZyXEL/ZyXEL NBG6816.png'),
(27, 0, 'imence', 0, 0, ''),
(28, 0, 'imence', 0, 0, ''),
(29, 28, 'Huawei - AX3', 80, 4, 'products/huawei/Huawei - AX3.jpg'),
(30, 0, 'imence', 0, 0, ''),
(31, 30, 'XIAOMI MI AX1800', 90, 4, 'products/xiomi/XIAOMI MI AX1800.jpg'),
(32, 30, 'Cisco CBS220 Smart', 1525, 4, 'products/switch/ciscoSwitch/Cisco CBS220 Smart 48.'),
(34, 0, 'imence', 0, 0, ''),
(35, 0, 'imence', 0, 0, ''),
(36, 35, 'ASUS TUF-AX5400', 211, 4, 'products/asus/ASUS TUF-AX5400.jpg'),
(37, 0, 'imence', 0, 0, ''),
(38, 37, 'Huawei - AX3 Pro', 102, 4, 'products/huawei/Huawei - AX3 Pro.jpg'),
(39, 0, 'imence', 0, 0, ''),
(40, 39, 'MobileY Y\r\n', 41, 7, 'photo/service.png'),
(41, 0, 'imence', 0, 0, ''),
(42, 41, 'Cisco CBS220 Smart', 1525, 8, 'products/switch/ciscoSwitch/Cisco CBS220 Smart 48.'),
(43, 0, 'imence', 0, 0, ''),
(44, 0, 'imence', 0, 0, ''),
(45, 0, 'imence', 0, 0, ''),
(46, 0, 'imence', 0, 0, ''),
(47, 0, 'imence', 0, 0, ''),
(48, 0, 'imence', 0, 0, ''),
(49, 48, 'Dell EMC N3248X-ON', 10713, 9, 'products/switch/dellSwitch/Dell EMC PowerSwitch N3'),
(50, 0, 'imence', 0, 0, ''),
(51, 50, 'MobileY Y\r\n', 41, 9, 'photo/service.png'),
(52, 0, 'imence', 0, 0, ''),
(53, 0, 'imence', 0, 0, ''),
(54, 53, 'Dell EMC S4128F-ON Switch', 11118, 10, 'products/switch/dellSwitch/Dell EMC S4128F-ON.jpeg'),
(55, 0, 'imence', 0, 0, ''),
(56, 55, 'TP-LINK ARCHER C20 /750', 50, 11, 'products/tp-link/TP-LINK ARCHER C20 750.jpg'),
(57, 55, 'MobileY Y\r\n', 41, 11, 'photo/service.png'),
(58, 0, 'imence', 0, 0, ''),
(59, 58, 'Huawei - AX3 Pro', 102, 12, 'products/huawei/Huawei - AX3 Pro.jpg'),
(60, 0, 'imence', 0, 0, ''),
(61, 60, 'ASUS TUF-AX5400', 211, 13, 'products/asus/ASUS TUF-AX5400.jpg'),
(62, 60, 'Cisco CBS350', 4050, 13, 'products/switch/ciscoSwitch/Cisco CBS350.jpeg'),
(64, 0, 'imence', 0, 0, ''),
(65, 64, 'MobileY Y\r\n', 41, 13, 'photo/service.png'),
(66, 0, 'imence', 0, 0, ''),
(67, 66, 'TP-LINK WR841N', 28, 14, 'products/tp-link/TP-LINK WR841N.jpg');

-- --------------------------------------------------------

--
-- Структура на таблица `registration`
--

CREATE TABLE `registration` (
  `id` int(15) NOT NULL,
  `userName` varchar(20) NOT NULL,
  `number` int(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Схема на данните от таблица `registration`
--

INSERT INTO `registration` (`id`, `userName`, `number`, `email`, `password`) VALUES
(1, 'Salioka BUpacha', 1111111111, 'saliooka@abv.bg', 'saliooka12'),
(5, 'test', 2147483647, 'test@gmail.com', '123456789'),
(6, 'dani', 888660954, 'dani@gmail.com', '222222222'),
(7, 'dan4enceto', 877662558, 'dan40@gmail.com', '987654321'),
(8, 'ASEN', 877662558, 'danninikolov08@gmail.com', '123456789'),
(9, 'spasetomnlud', 877662558, 'spas40@gmail.com', 'spas40'),
(10, 'asen', 877662558, 'vladi@gmai.com', 'vladi'),
(11, 'kris', 877662558, 'az@gmail.com', '123456789'),
(12, 'ivan44', 877662558, 'ivan@gmail.com', 'ivan'),
(13, 'Gosho', 877662558, 'gosho@gmail.com', 'gosho'),
(14, 'stef40', 877662558, 'stef40@gmail.com', '123456789');

-- --------------------------------------------------------

--
-- Структура на таблица `router`
--

CREATE TABLE `router` (
  `id` int(11) NOT NULL,
  `ime` varchar(100) NOT NULL,
  `skorost` varchar(500) NOT NULL,
  `sigurnost` varchar(500) NOT NULL,
  `EAN` varchar(25) NOT NULL,
  `cena` double NOT NULL,
  `marka` varchar(50) NOT NULL,
  `type` varchar(10) NOT NULL,
  `snimka` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Схема на данните от таблица `router`
--

INSERT INTO `router` (`id`, `ime`, `skorost`, `sigurnost`, `EAN`, `cena`, `marka`, `type`, `snimka`) VALUES
(3, 'ASUS RT-AC58U /AC1200', '\r\nСКОРОСТ	400+867 Mbps\r\n', 'СИГУРНОСТ	WPS, WPA/WPA2', 'EAN	192876412466', 69.99, 'ASUS ', 'router', 'products/asus/ASUS RT-AC58U AC1200.jpg'),
(4, 'ASUS RT-AX55 /AX1800', 'СКОРОСТ	574+1201Mbps', 'СИГУРНОСТ	WPA/WPA2', 'EAN	4718017728485', 180.99, 'ASUS ', 'router', 'products/asus/ASUS RT-AX55 AX1800.jpg'),
(5, 'ASUS TUF-AX5400', 'СКОРОСТ	574+4804 Mbps', 'СИГУРНОСТ WPA/WPA2', 'EAN	4711081173939', 210.85, 'ASUS ', 'router', 'products/asus/ASUS TUF-AX5400.jpg'),
(6, 'Huawei - AX3', 'СКОРОСТ	2402Mbps+574Mbp\r\n', 'СИГУРНОСТ	WPS, WPA/WPA2', 'EAN	6972453162823', 79.99, 'Huawei ', 'router', 'products/huawei/Huawei - AX3.jpg'),
(7, 'Huawei - AX3 Pro', 'СКОРОСТ 2402Mbps+574Mbp ', 'СИГУРНОСТ WPS, WPA/WPA2', 'EAN 6972453162823', 101.99, 'Huawei ', 'router', 'products/huawei/Huawei - AX3 Pro.jpg'),
(8, 'TP-LINK ARCHER A5 /AC1200', '\r\nСКОРОСТ	300+867Mbps\r\n', 'СИГУРНОСТ	WPS, WPA/WPA2', 'EAN	6935364084134', 45.99, 'TP-LINK', 'router', 'products/tp-link/TP-LINK ARCHER A5 AC1200.jpg'),
(9, 'TP-LINK ARCHER AX73 /AX5400', 'СКОРОСТ	4804+574 Mbps\r\n', 'СИГУРНОСТ	WPA, WPA2, WPA3', 'EAN	6935364010263', 229.99, 'TP-LINK', 'router', 'products/tp-link/TP-LINK ARCHER AX73AX5400.jpg'),
(10, 'TP-LINK ARCHER C20 /750', '\r\nСКОРОСТ	300Mbps+433Mbps\r\n', 'СИГУРНОСТ	WEP,WPA/WPA2', 'EAN	6935364091606', 49.5, 'TP-LINK', 'router', 'products/tp-link/TP-LINK ARCHER C20 750.jpg'),
(11, 'TP-LINK ARCHER C54 /AC1200', 'СКОРОСТ	867+300 Mbps\r\n', 'СИГУРНОСТ	WEP,WPA,WPA2', 'EAN	6935364089337', 70.1, 'TP-LINK', 'router', 'products/tp-link/TP-LINK ARCHER C54.jpg'),
(12, 'TP-LINK ARCHER C1200', 'СКОРОСТ	867+300 Mbps\r\n', 'СИГУРНОСТ	WPA, WPA2,WEP', 'EAN	6935364096052', 75.25, 'TP-LINK', 'router', 'products/tp-link/TP-LINK ARCHER C1200.jpg'),
(13, 'TP-LINK TL-MR3420 4G', 'СКОРОСТ	300+867 Mbps\r\n', 'СИГУРНОСТ	WPA, WPA2,WEP', 'EAN	6935364051495', 56.36, 'TP-LINK', 'router', 'products/tp-link/TP-LINK TL-MR3420 4G.jpg'),
(14, 'TP-LINK WR841N', 'СКОРОСТ	300 MBPS\r\n', 'СИГУРНОСТ	WEP/WPA/WPA2', 'EAN	6935364051242', 27.99, 'TP-LINK', 'router', 'products/tp-link/TP-LINK WR841N.jpg'),
(15, 'XIAOMI MI 4A', 'СКОРОСТ	300+867 Mbps\r\n', 'СИГУРНОСТ	WPA-PSK/WPA-PSK2', 'EAN	6970244525536', 44.99, 'XIAOMI', 'router', 'products/xiomi/XIAOMI MI 4A.jpg'),
(16, 'XIAOMI MI AX1800', 'СКОРОСТ	574+1201 Mbps\r\n', 'СИГУРНОСТ	WPA-PSK/WPA2-PSK/WPA3-SAE', 'EAN	6934177723643', 89.9, 'XIAOMI', 'router', 'products/xiomi/XIAOMI MI AX1800.jpg'),
(17, 'ZyXEL - NBG6604', 'СКОРОСТ	300Mbps+433Mbps', 'СИГУРНОСТ	WPA, WPA2, WPA3', 'EAN    4718937596072', 180.99, 'ZyXEL', 'router', 'products/ZyXEL/ZyXEL - NBG6604.jpg'),
(18, 'ZyXEL NBG6816', 'СКОРОСТ	400+867 Mbps', 'СИГУРНОСТ WPA/WPA2', 'EAN    6977753162854', 177.99, 'ZyXEL', 'router', 'products/ZyXEL/ZyXEL NBG6816.png');

-- --------------------------------------------------------

--
-- Структура на таблица `service`
--

CREATE TABLE `service` (
  `id` int(11) NOT NULL,
  `ime` varchar(50) NOT NULL,
  `harakteristika` varchar(150) NOT NULL,
  `cena` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Схема на данните от таблица `service`
--

INSERT INTO `service` (`id`, `ime`, `harakteristika`, `cena`) VALUES
(9, 'YorNet 1000', '500 MB Web hosting пространство<br>\r\nОптичнen интернет 1000 Mbps<br>\r\n3 динамични, възможност<br>\r\nза статични IP адреси', 15.99),
(10, 'YorNet 1500\r\n', '500 MB Web hosting пространство<br>\r\nОптичнen интернет 1500 Mbps<br>\r\n3 динамични, възможност<br>\r\nза статични IP адреси', 23.99),
(11, '\r\nYorNet 2000\r\n', '500 MB Web hosting пространство<br>\r\nОптичнen интернет 2000 Mbps<br>\r\n3 динамични, възможност<br>\r\nза статични IP адреси', 40.99),
(12, 'YorNet 3000\r\n', '500 MB Web hosting пространство<br>\r\nОптичнen интернет 3000 Mbps<br>\r\n3 динамични, възможност<br>\r\nза статични IP адреси', 59.99),
(13, 'MobileY M', '250 MB мобилен интернет<br>\r\n15 GB облачно пространство<br>\r\nYpay дигитален портфейл<br>\r\n12 месечен договор', 10.99),
(14, 'MobileY L\r\n', '350 MB мобилен интернет<br>\r\n15 GB облачно пространство<br>\r\nYpay дигитален портфейл<br>\r\n12 месечен договор', 15.99),
(15, 'MobileY X\r\n', '500 MB мобилен интернет<br>\r\n15 GB облачно пространство<br>\r\nYpay дигитален портфейл<br>\r\n24 месечен договор', 32.99),
(16, 'MobileY Y\r\n', '990 MB мобилен интернет<br>\r\n15 GB облачно пространство<br>\r\nYpay дигитален портфейл<br>\r\n36 месечен договор', 40.99);

-- --------------------------------------------------------

--
-- Структура на таблица `switch`
--

CREATE TABLE `switch` (
  `id` int(11) NOT NULL,
  `ime` varchar(50) NOT NULL,
  `portove` varchar(100) NOT NULL,
  `zahranvane` varchar(100) NOT NULL,
  `pamet` varchar(100) NOT NULL,
  `kapacitet` varchar(100) NOT NULL,
  `mac_adres` varchar(100) NOT NULL,
  `cena` double NOT NULL,
  `marka` varchar(50) NOT NULL,
  `type` varchar(50) NOT NULL,
  `snimka` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Схема на данните от таблица `switch`
--

INSERT INTO `switch` (`id`, `ime`, `portove`, `zahranvane`, `pamet`, `kapacitet`, `mac_adres`, `cena`, `marka`, `type`, `snimka`) VALUES
(1, 'Asustor ASW205T', 'Общ брой портове\r\n5', 'Захранване\r\nExternal Power Adapter 5 V/1 A', '2.5Gbps /1Gbps / 100M', 'Капацитет за маршрутизиране\r\n25 Gbps', 'MAC адреси\r\nMAC Address Table: 16K', 261.99, 'asus', 'switch', 'products/switch/asusSwitch/Asustor ASW205T.jpeg'),
(2, 'Cisco CBS220', 'Общ брой портове\r\n25', 'Захранване\r\nInternal, 100-240 V, 50-60 Hz', 'Памет\r\nFlash: 64 MB, CPU memory: 256 ', 'Капацитет за маршрутизиране\r\n56 Gbps', 'MAC адреси\r\nUp to 8 192', 399.99, 'cisco', 'switch', 'products/switch/ciscoSwitch/Cisco CBS220 Smart 24.jpeg'),
(3, 'Cisco CBS220 Smart', 'Общ брой портове\r\n52', 'Захранване\r\nInternal, 100-240 V, 50-60 Hz', 'Памет\r\nFlash: 64 MB, CPU memory: 256 ', 'Капацитет за маршрутизиране\r\n10 Gbps', 'MAC адреси\r\nUp to 8 192 ', 1525, 'cisco', 'switch', 'products/switch/ciscoSwitch/Cisco CBS220 Smart 48.jpeg'),
(4, 'Cisco CBS220', 'Общ брой портове\r\n28', 'Захранване\r\nInternal, 100-240 V, 50-60 Hz', '24x RJ-45 10/100/1000 Mbps', 'Капацитет за маршрутизиране\r\n128 Gbps', 'MAC адреси\r\nUp to 8 192', 769.99, 'cisco', 'switch', 'products/switch/ciscoSwitch/cisco CBS220.jpeg'),
(5, 'Cisco CBS350', 'Общ брой портове\r\n25', 'Захранване\r\nInternal (100-240V, 50-60 Hz)', 'Памет (Flash, RAM)\r\nFlash: 256 MB; CPU memory: 512 MB, Packet buffer: 3 MB', 'Капацитет за маршрутизиране\r\n480 Gbps', 'MAC адреси\r\n16K', 4049.99, 'cisco', 'switch', 'products/switch/ciscoSwitch/Cisco CBS350.jpeg'),
(6, 'Cisco SG220', 'Общ брой портове\r\n26', 'Захранване\r\nInternal Power Supply: 100-240 V, 50-60 Hz', 'Памет (Flash, RAM)\r\nFlash Memory: 32 MB; RAM: 128 MB', 'Капацитет за маршрутизиране\r\n52 Gbps', 'MAC адреси\r\n8192 MAC address table size', 446.99, 'cisco', 'switch', 'products/switch/ciscoSwitch/Cisco SG220-26.jpeg'),
(7, 'Dell EMC N3208PX-ON', 'Общ брой портове\r\n8', 'Захранване\r\n1x 320W AC PSU included', 'Памет (Flash, RAM)\r\n4 MB Buffer memory', 'Капацитет за маршрутизиране\r\n88 Gbps', 'MAC адреси\r\n32K', 4359.99, 'cisco', 'switch', 'products/switch/dellSwitch/Dell EMC PowerSwitch N3208PX-ON.jpeg'),
(8, 'Dell EMC N3248P-ON', 'Общ брой портове\r\n54', 'Захранване\r\n1x 1050W AC PSU included', 'Памет (Flash, RAM)\r\n4 GB DDR4 SO-DIMM, 8 GB mSATA 2.0/M.2 SSD', 'Капацитет за маршрутизиране\r\n576 Gbps', 'MAC адреси\r\n32K', 7663, 'dell', 'switch', 'products/switch/dellSwitch/Dell EMC PowerSwitch N3248P-ON.jpeg'),
(9, 'Dell EMC N3248X-ON', 'Общ брой портове\r\n54', 'Захранване\r\n1x 550W AC PSU', 'Памет (Flash, RAM)\r\n4 GB DDR4 SO-DIMM', 'Капацитет за маршрутизиране\r\n1560 Gbps', 'MAC адреси\r\n32K', 10713, 'dell', 'switch', 'products/switch/dellSwitch/Dell EMC PowerSwitch N3248X-ON.jpeg'),
(10, 'Dell EMC S4128F-ON Switch', 'Общ брой портове\r\n30', 'Захранване\r\nRedundant, hot-swappable power supplies', 'Памет (Flash, RAM)\r\nRAM: 4 GB', 'Капацитет за маршрутизиране/превключване, Gbps\r\n960 Gbps', 'MAC адреси\r\n272000 MAC ', 11118, 'dell', 'switch', 'products/switch/dellSwitch/Dell EMC S4128F-ON.jpeg'),
(11, 'Dell EMC N1108EP-ON', 'Основни портове, тип\r\n8x 10/100/1000', 'Захранване External power adapter: 137W of POE power', 'Памет (Flash, RAM)\r\nFlash memory: 1GB; Packet buffer memory: 1.5MB', 'Капацитет за маршрутизиране\r\n24Gbps', 'MAC адреси\r\n16K', 999.99, 'dell', 'switch', 'products/switch/dellSwitch/Dell EMC Switch N1108EP-ON.jpeg'),
(12, ' ZyXEL GS-105Sv2', 'Общ брой портове\r\n5', 'Захранване\r\nPower Supply: Input: 100-240 V AC; Output: 5 V DC, 1 A', 'Памет (Flash, RAM)\r\nMemory buffer: 128 KB', 'Капацитет за маршрутизиране\r\n10 Gbps', 'MAC адреси\r\n2000 MAC', 34.99, 'ZyXEL', 'switch', 'products/switch/ZyXELSwitch/ZyXEL GS-105Sv2.jpeg'),
(13, 'ZyXEL ES-105AV3', 'Общ брой портове\r\n5', 'Захранване\r\nExternal switching power adapter', '', 'Капацитет за маршрутизиране\r\n1.0 Gbps', 'MAC адреси\r\n1000 MAC', 24, 'ZyXEL', 'switch', 'products/switch/ZyXELSwitch/ZyXEL ES-105AV3.jpeg'),
(14, 'ZyXEL GS1350-6HP', 'Общ брой портове\r\n6', 'Захранване\r\nExternal Power supply: Input voltage - 52 V - 57 V DC\r\n', '', 'Капацитет за маршрутизиране\r\n12 Gbps', 'MAC адреси\r\n8000 MAC address table size\r\n', 336, 'ZyXEL', 'switch', 'products/switch/ZyXELSwitch/ZyXEL GS1350-6HP.jpeg'),
(15, 'ZyXEL GS1920-8HPv2', 'Общ брой портове\r\n6', 'Захранване\r\nExternal Power supply: Input voltage - 52 V - 57 V DC', '', 'Капацитет за маршрутизиране\r\n12 Gbps', 'MAC адреси\r\n8000 MAC', 336.99, 'ZyXEL', 'switch', 'products/switch/ZyXELSwitch/ZyXEL GS1920-8HPv2.jpeg'),
(16, 'ZyXEL GS1920-24v2', 'Общ брой портове\r\n28', 'Захранване\r\nInput voltage of AC: 100 - 240 V AC, 50/60 Hz', 'Памет (Flash, RAM)\r\nFlash Memory: 32 MB; RAM: 256 MB', 'Капацитет за маршрутизиране\r\n56 Gbps', 'MAC адреси\r\n16K MAC', 402, 'ZyXEL', 'switch', 'products/switch/ZyXELSwitch/ZyXEL GS1920-24v2.jpeg');

--
-- Indexes for dumped tables
--

--
-- Индекси за таблица `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`primID`),
  ADD KEY `id` (`id`);

--
-- Индекси за таблица `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Индекси за таблица `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`id`);

--
-- Индекси за таблица `router`
--
ALTER TABLE `router`
  ADD PRIMARY KEY (`id`);

--
-- Индекси за таблица `service`
--
ALTER TABLE `service`
  ADD PRIMARY KEY (`id`);

--
-- Индекси за таблица `switch`
--
ALTER TABLE `switch`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `primID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=154;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=68;

--
-- AUTO_INCREMENT for table `registration`
--
ALTER TABLE `registration`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `router`
--
ALTER TABLE `router`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `service`
--
ALTER TABLE `service`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `switch`
--
ALTER TABLE `switch`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Ограничения за дъмпнати таблици
--

--
-- Ограничения за таблица `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`id`) REFERENCES `registration` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
